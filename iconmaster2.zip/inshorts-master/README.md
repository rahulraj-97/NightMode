# inshorts
A Firefox browser supported web extension to dim lights for inShorts webapp
